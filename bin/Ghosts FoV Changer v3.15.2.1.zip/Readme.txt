**********************************
* Ghosts FoV Changer by AgentRev *
**********************************

If you have questions, suggestions, or found a bug, tweet me @AgentRev or drop me an email at agentrevo@gmail.com

**********************************

DISCLAIMER: I, AgentRev, am not responsible for anything that happens to your CoD:Ghosts profile and/or Steam account during usage of the Ghosts FoV Changer. The official version is distributed on https://github.com/AgentRev/CoD-FoV-Changers; if acquiring it from a different source, be on the lookout for anything suspicious.

ACTIVISION, CALL OF DUTY, MODERN WARFARE, and CALL OF DUTY GHOSTS are trademarks of Activision Publishing, Inc.
No copyright infringement intended.

**********************************

Changelog:

- v3.15.2.1 (2025-12-29): Updated memory offsets
- v3.15.2.0 (2019-07-15): Updated memory offsets, fixed URLs, switched from .NET Framework 3.5 to 4
- v3.2.625.2 (2013-11-16): Increased max FoV to 100 due to high demand, Fixed more "offset not found" errors with Singleplayer
- v3.2.625.1 (2013-11-10): Fixed some "offset not found" errors with Singleplayer
- v3.2.625.0 (2013-11-09): Initial release

**********************************

Frequently Asked Questions:


Q: Can FoV changers cause a ban from Infinity Ward or Valve Anti-Cheat?
-
A: Candice Capen, from Infinity Ward, confirmed that FoV changers are ALLOWED for Ghosts: https://twitter.com/candyslexia/status/400020567236939776
Transcript: "I've found out we aren't banning for anyone using the FOV changer."


Q: FoV Changer has stopped working / errors about missing DLL files or .NET Framework
-
A: Send me an email at agentrevo@gmail.com, and if you have any error message, be sure to include a screenshot so I can try to diagnose the problem.
Before emailing me, I'd suggest that you make sure you have the .NET Framework 4 properly installed: 
https://www.microsoft.com/download/details.aspx?id=17851


Q: Why are sniper scopes smaller when increasing the FoV?
-
A: The new 3D scopes in Ghosts seem to be linked to the FoV value. It is most likely an unintended bug from Infinity Ward, but since the FoV is locked by default, they probably won't care enough to fix it. I don't think a permanent fix will ever be possible.


Q: How come the zoomed-in (aimed-down sight) FoV won't change too?
-
A: That's how the "cg_fov" variable has ever worked. It would be easy to do so by switching to the "cg_fovScale" variable,
but it would allow people to use the FoV changer as an all-purpose variable zoom, which is seen as an unfair advantage by many.


Q: How come your FoV changer doesn't need to be updated each time the game receives a patch?
-
A: Because unlike some lazy coders out there, I included a memory pattern research system which is able to locate the new FoV value when it changes. When the memory offset is found, it is saved in the settings file.


Q: omgwtfbbq, can u maek this for xbox/playstashun/mac?! pls!!1!
-
A: No.


Q: So what's behind this stuff?
-
A: Everything is coded in C#, and interactions with the game's memory are made via P/Invoke calls to kernel32's Read/WriteProcessMemory. The executable is compiled for 64-bits like Ghosts, and uses the .NET Framework 4.
