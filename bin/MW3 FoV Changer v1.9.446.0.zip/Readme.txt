*******************************
* MW3 FoV Changer by AgentRev *
*******************************

If you find a bug or have a suggestion, drop me an email at agentrevo@gmail.com


Q: Can using a FoV changer cause a ban from Infinity Ward or Valve Anti-Cheat?
-
A: No. -> http://community.callofduty.com/message/205674719
However, this only applies to MW3. Using a FoV changer in CoD:Ghosts can result in a ban.


Q: FoV Changer has stopped working / errors about missing DLL files or .NET Framework
-
A: Send me an email at agentrevo@gmail.com, and if you have any error message, be sure to include a screenshot so I can try to diagnose the problem. Before emailing me, I'd suggest that you make sure the latest .NET Framework is properly installed: 
http://www.microsoft.com/download/confirmation.aspx?id=17851


Q: How come the zoomed-in (aimed-down sight) FoV won't change too?
-
A: That's how the "cg_fov" variable has ever worked. It would be easy to do so by using "cg_fovScale", but I don't want a bunch of whiners crying out it would allow people to zoom out with snipers without using the variable scope attachment and stuff, etc.


Q: How come your FoV changer doesn't need to be updated each time the game receives a patch?
-
A: Because unlike some lazy coders out there, I included a memory pattern research system which is able to locate the new FoV value when it changes. When the memory offset is found, it is saved in the settings file.


Q: omgwtfbbq, can u maek this for xbox/ps3?! pls!!1!
-
A: No.


Q: So what's behind this shit?
-
A: Everything is coded in C#, and interactions with the game's memory are made via P/Invoke calls to kernel32's Read/WriteProcessMemory. At first, stuff related to the memory was coded in C++, but having a DLL to carry was kind of annoying, so I converted the C++ code into a C# class.

I compiled it for .NET 2.0, since it is intended to be a portable EXE and I believed it would reduce compatibity issues due to not having the latest framework installed, althought .NET 3.5 could have been a better choice for increased functionality, since it is already included with Windows 7.
