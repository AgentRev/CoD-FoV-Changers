**********************************
* MW2 MP FoV Changer by AgentRev *
**********************************

If you have questions, suggestions, or found a bug, drop me an email at agentrevo@gmail.com

**********************************

DISCLAIMER: I, AgentRev, am not responsible for anything that happens to your CoD profile and/or Steam account during usage of the FoV Changer. The official version is distributed on www.MapModNews.com, or by http://reddit.com/u/AgentRev, http://steamcommunity.com/id/AgentRev, or agentrevo@gmail.com; if acquiring it from a different source, be on the lookout for anything suspicious.

ACTIVISION, CALL OF DUTY, MODERN WARFARE, and MODERN WARFARE 2 are trademarks of Activision Publishing, Inc.
No copyright infringement intended.

**********************************

Changelog:

- v1.2.211.0 (2015-09-09): Fix for game update v1.2.211
- v1.2.208.1 (early 2012): Minor bugfix
- v1.2.208.0 (early 2012): Initial release

**********************************

Frequently Asked Questions:


Q: Can FoV changers cause a ban from Infinity Ward or Valve Anti-Cheat?
-
A: Candice Capen, from Infinity Ward, confirmed that FoV changers are ALLOWED for MW3: https://community.callofduty.com/message/205674719
Transcript: "We do not mind if a PC user has the FOV changer mod."
So, there's no reason it wouldn't be allowed for MW2 either.


Q: FoV Changer has stopped working / errors about missing DLL files or .NET Framework
-
A: Send me an email at agentrevo@gmail.com, and if you have any error message, be sure to include a screenshot so I can try to diagnose the problem.
Before emailing me, I'd suggest that you make sure you have the .NET Framework 2.0 properly installed: 

http://www.microsoft.com/download/details.aspx?id=1639


Q: How come the zoomed-in (aimed-down sight) FoV won't change too?
-
A: That's how the "cg_fov" variable has ever worked. It would be easy to do so by switching to the "cg_fovScale" variable,
but it would allow people to use the FoV changer as an all-purpose variable zoom, which is seen as an unfair advantage by many.


Q: omgwtfbbq, can u maek this for xbox/playstashun?! pls!!1!
-
A: No.


Q: So what's behind this stuff?
-
A: Everything is coded in C#, and interactions with the game's memory are made via P/Invoke calls to kernel32's Read/WriteProcessMemory. The executable is compiled in x86, and uses the .NET Framework 2.0
